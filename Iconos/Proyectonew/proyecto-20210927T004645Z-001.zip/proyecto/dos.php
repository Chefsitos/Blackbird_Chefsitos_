<? php
$texto=$REQUEST['Correo electronico'];
?>
<p><? php echo $texto; ?> </p>