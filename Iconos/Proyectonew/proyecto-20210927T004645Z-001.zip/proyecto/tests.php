<?php 
require_once('interface.php');
require_once('modelo.php');
require_once('dominio.php');
require_once('persistencia.php');
require_once('Desayuno.php');
//paginon_si();
//var_dump(acceder_usuario('1'));
//presentar_Home();
//presentar_menu();
//presentar_head();

?>