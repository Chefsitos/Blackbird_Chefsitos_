const seccionesPagina = new fullpage('#fullpage',{
		 navigation: false, // Muesta la barra de navegación.
});
